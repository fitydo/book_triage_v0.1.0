Book Triage - macOS Installation

Requirements:
- Python 3.12 or higher
- Homebrew (recommended)

Installation:
1. chmod +x install.sh
2. ./install.sh
3. ./start.sh to run the application

Works on:
- macOS 10.15+ (Intel & Apple Silicon)
