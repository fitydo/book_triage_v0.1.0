Book Triage - Windows Installation

Requirements:
- Python 3.12 or higher
- Internet connection for dependencies

Installation:
1. Double-click install.bat
2. Wait for installation to complete
3. Double-click start.bat to run the application

Troubleshooting:
- If Python is not found, install from python.org
- Run as Administrator if permission errors occur
