Book Triage - Linux Installation

Requirements:
- Python 3.12 or higher
- sudo access for system dependencies

Installation:
1. chmod +x install.sh
2. ./install.sh
3. ./start.sh to run the application

Tested on:
- Ubuntu 20.04+
- CentOS 8+
- Debian 11+
